import streamlit as st
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

def calculate_market_volatility(data):
    """
    Calculate market volatility based on price data
    
    Parameters:
    data (DataFrame): Historical price data with 'Close' column
    
    Returns:
    float: Volatility score (0-100)
    """
    if data is None or len(data) < 2:
        return 50  # Default to neutral if not enough data
    
    # Calculate daily returns
    if 'Close' in data.columns:
        returns = data['Close'].pct_change().dropna()
    else:
        returns = data['close_price'].pct_change().dropna()
    
    if len(returns) < 2:
        return 50
    
    # Calculate volatility (standard deviation of returns)
    volatility = returns.std() * 100
    
    # Normalize to 0-100 scale
    # Typically, daily volatility of 1-3% is normal for stocks
    normalized_volatility = min(100, max(0, volatility * 20))
    
    return normalized_volatility

def get_mood_description(volatility_score):
    """
    Get mood description based on volatility score
    
    Parameters:
    volatility_score (float): Volatility score (0-100)
    
    Returns:
    tuple: (mood_name, description, emoji, color)
    """
    if volatility_score < 20:
        return ("Calm Waters", 
                "The market is sailing smoothly with low volatility.", 
                "😌", "#26a69a")  # Green - same as positive stock change
    elif volatility_score < 40:
        return ("Steady Seas", 
                "Markets showing normal, healthy movement.", 
                "🙂", "#26a69a")  # Green - same as positive stock change
    elif volatility_score < 60:
        return ("Choppy Waters", 
                "Some waves in the market, moderate volatility.", 
                "😐", "#ffcc00")  # Yellow - warning
    elif volatility_score < 80:
        return ("Rough Seas", 
                "Hang onto your life vest! High market volatility.", 
                "😬", "#ff9900")  # Orange - caution
    else:
        return ("Perfect Storm", 
                "Extremely volatile market conditions! All hands on deck!", 
                "😱", "#ef5350")  # Red - same as negative stock change

def get_captain_svg(mood):
    """
    Get SVG for the sea captain based on the market mood
    
    Parameters:
    mood (str): Mood name (Calm, Steady, Choppy, Rough, Storm)
    
    Returns:
    str: SVG content
    """
    # Base captain SVG with different expressions based on mood
    if mood == "Calm Waters":
        # Happy, relaxed captain
        return """
        <svg width="200" height="200" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
            <!-- Captain's face - calm and happy -->
            <circle cx="100" cy="80" r="50" fill="#FFD7A8" stroke="#000" stroke-width="2"/>
            
            <!-- Captain's hat -->
            <path d="M50 60 H150 C130 30 70 30 50 60 Z" fill="#003366" stroke="#000" stroke-width="2"/>
            <rect x="75" y="35" width="50" height="10" fill="gold" stroke="#000" stroke-width="1"/>
            
            <!-- Captain's beard -->
            <path d="M70 100 Q100 140 130 100" fill="none" stroke="#DDDDDD" stroke-width="15"/>
            
            <!-- Happy eyes -->
            <path d="M80 70 Q85 65 90 70" stroke="#000" stroke-width="2" fill="none"/>
            <path d="M110 70 Q115 65 120 70" stroke="#000" stroke-width="2" fill="none"/>
            
            <!-- Smiling mouth -->
            <path d="M85 95 Q100 105 115 95" stroke="#000" stroke-width="2" fill="none"/>
            
            <!-- Pipe -->
            <path d="M115 100 L130 95" stroke="#8B4513" stroke-width="3" fill="none"/>
            <ellipse cx="132" cy="95" rx="3" ry="2" fill="#8B4513"/>
            
            <!-- Text -->
            <text x="100" y="160" text-anchor="middle" font-family="Arial" font-size="14" font-weight="bold">Captain says:</text>
            <text x="100" y="180" text-anchor="middle" font-family="Arial" font-size="12">"Smooth sailing ahead!"</text>
        </svg>
        """
    elif mood == "Steady Seas":
        # Content captain
        return """
        <svg width="200" height="200" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
            <!-- Captain's face - steady -->
            <circle cx="100" cy="80" r="50" fill="#FFD7A8" stroke="#000" stroke-width="2"/>
            
            <!-- Captain's hat -->
            <path d="M50 60 H150 C130 30 70 30 50 60 Z" fill="#003366" stroke="#000" stroke-width="2"/>
            <rect x="75" y="35" width="50" height="10" fill="gold" stroke="#000" stroke-width="1"/>
            
            <!-- Captain's beard -->
            <path d="M70 100 Q100 140 130 100" fill="none" stroke="#DDDDDD" stroke-width="15"/>
            
            <!-- Content eyes -->
            <circle cx="85" cy="70" r="3" fill="#000"/>
            <circle cx="115" cy="70" r="3" fill="#000"/>
            
            <!-- Slight smile -->
            <path d="M85 95 Q100 102 115 95" stroke="#000" stroke-width="2" fill="none"/>
            
            <!-- Pipe -->
            <path d="M115 100 L130 95" stroke="#8B4513" stroke-width="3" fill="none"/>
            <ellipse cx="132" cy="95" rx="3" ry="2" fill="#8B4513"/>
            
            <!-- Text -->
            <text x="100" y="160" text-anchor="middle" font-family="Arial" font-size="14" font-weight="bold">Captain says:</text>
            <text x="100" y="180" text-anchor="middle" font-family="Arial" font-size="12">"Good weather for sailing!"</text>
        </svg>
        """
    elif mood == "Choppy Waters":
        # Neutral captain
        return """
        <svg width="200" height="200" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
            <!-- Captain's face - neutral -->
            <circle cx="100" cy="80" r="50" fill="#FFD7A8" stroke="#000" stroke-width="2"/>
            
            <!-- Captain's hat -->
            <path d="M50 60 H150 C130 30 70 30 50 60 Z" fill="#003366" stroke="#000" stroke-width="2"/>
            <rect x="75" y="35" width="50" height="10" fill="gold" stroke="#000" stroke-width="1"/>
            
            <!-- Captain's beard -->
            <path d="M70 100 Q100 140 130 100" fill="none" stroke="#DDDDDD" stroke-width="15"/>
            
            <!-- Alert eyes -->
            <circle cx="85" cy="70" r="4" fill="#000"/>
            <circle cx="115" cy="70" r="4" fill="#000"/>
            
            <!-- Straight mouth -->
            <line x1="85" y1="95" x2="115" y2="95" stroke="#000" stroke-width="2"/>
            
            <!-- Hand on telescope -->
            <ellipse cx="135" cy="80" rx="10" ry="5" fill="#FFD7A8" stroke="#000" stroke-width="1" transform="rotate(-20 135 80)"/>
            <rect x="115" y="75" width="25" height="10" fill="#8B4513" stroke="#000" stroke-width="1" transform="rotate(-20 115 75)"/>
            
            <!-- Text -->
            <text x="100" y="160" text-anchor="middle" font-family="Arial" font-size="14" font-weight="bold">Captain says:</text>
            <text x="100" y="180" text-anchor="middle" font-family="Arial" font-size="12">"Keep an eye on those clouds!"</text>
        </svg>
        """
    elif mood == "Rough Seas":
        # Concerned captain
        return """
        <svg width="200" height="200" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
            <!-- Captain's face - concerned -->
            <circle cx="100" cy="80" r="50" fill="#FFD7A8" stroke="#000" stroke-width="2"/>
            
            <!-- Captain's hat - slightly tilted -->
            <path d="M55 55 H155 C135 25 75 25 55 55 Z" fill="#003366" stroke="#000" stroke-width="2"/>
            <rect x="80" y="30" width="50" height="10" fill="gold" stroke="#000" stroke-width="1"/>
            
            <!-- Captain's beard - windblown -->
            <path d="M70 100 Q100 145 130 100" fill="none" stroke="#DDDDDD" stroke-width="15"/>
            
            <!-- Worried eyes -->
            <path d="M80 65 Q85 75 90 65" stroke="#000" stroke-width="2" fill="none"/>
            <path d="M110 65 Q115 75 120 65" stroke="#000" stroke-width="2" fill="none"/>
            
            <!-- Concerned mouth -->
            <path d="M90 100 Q100 90 110 100" stroke="#000" stroke-width="2" fill="none"/>
            
            <!-- Hand gripping wheel -->
            <circle cx="155" cy="90" r="15" fill="none" stroke="#8B4513" stroke-width="4"/>
            <circle cx="155" cy="90" r="5" fill="#8B4513" stroke="#000" stroke-width="1"/>
            <line x1="155" y1="75" x2="155" y2="105" stroke="#8B4513" stroke-width="2"/>
            <line x1="140" y1="90" x2="170" y2="90" stroke="#8B4513" stroke-width="2"/>
            <ellipse cx="145" cy="80" rx="8" ry="4" fill="#FFD7A8" stroke="#000" stroke-width="1"/>
            
            <!-- Text -->
            <text x="100" y="160" text-anchor="middle" font-family="Arial" font-size="14" font-weight="bold">Captain says:</text>
            <text x="100" y="180" text-anchor="middle" font-family="Arial" font-size="12">"Batten down the hatches!"</text>
        </svg>
        """
    else:  # "Perfect Storm"
        # Panicked captain
        return """
        <svg width="200" height="200" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
            <!-- Captain's face - panicked -->
            <circle cx="100" cy="80" r="50" fill="#FFD7A8" stroke="#000" stroke-width="2"/>
            
            <!-- Captain's hat - very tilted -->
            <path d="M45 65 H145 C125 35 65 35 45 65 Z" fill="#003366" stroke="#000" stroke-width="2" transform="rotate(-15 100 80)"/>
            <rect x="75" y="40" width="45" height="10" fill="gold" stroke="#000" stroke-width="1" transform="rotate(-15 100 80)"/>
            
            <!-- Captain's beard - very windblown -->
            <path d="M70 100 Q100 150 135 95" fill="none" stroke="#DDDDDD" stroke-width="15"/>
            
            <!-- Panicked eyes -->
            <circle cx="85" cy="70" r="6" fill="white" stroke="#000" stroke-width="2"/>
            <circle cx="115" cy="70" r="6" fill="white" stroke="#000" stroke-width="2"/>
            <circle cx="85" cy="70" r="2" fill="#000"/>
            <circle cx="115" cy="70" r="2" fill="#000"/>
            
            <!-- Shouting mouth -->
            <ellipse cx="100" cy="100" rx="15" ry="10" fill="#8B0000" stroke="#000" stroke-width="2"/>
            
            <!-- Both hands up -->
            <ellipse cx="65" cy="55" rx="8" ry="4" fill="#FFD7A8" stroke="#000" stroke-width="1" transform="rotate(-30 65 55)"/>
            <ellipse cx="135" cy="55" rx="8" ry="4" fill="#FFD7A8" stroke="#000" stroke-width="1" transform="rotate(30 135 55)"/>
            
            <!-- Waves in background -->
            <path d="M0 140 Q25 120 50 140 Q75 160 100 140 Q125 120 150 140 Q175 160 200 140" fill="none" stroke="#0066cc" stroke-width="5"/>
            <path d="M0 160 Q25 140 50 160 Q75 180 100 160 Q125 140 150 160 Q175 180 200 160" fill="none" stroke="#0066cc" stroke-width="5"/>
            
            <!-- Text -->
            <text x="100" y="160" text-anchor="middle" font-family="Arial" font-size="14" font-weight="bold">Captain says:</text>
            <text x="100" y="180" text-anchor="middle" font-family="Arial" font-size="12">"ABANDON SHIP!"</text>
        </svg>
        """

def display_market_mood(data, asset_type="stock", asset_name=""):
    """
    Display market mood indicator with animated sea captain
    
    Parameters:
    data (DataFrame): Historical price data
    asset_type (str): "stock" or "crypto"
    asset_name (str): Name of the asset
    """
    # Calculate volatility
    volatility_score = calculate_market_volatility(data)
    
    # Get mood based on volatility
    mood_name, mood_desc, mood_emoji, mood_color = get_mood_description(volatility_score)
    
    # Get captain SVG
    captain_svg = get_captain_svg(mood_name)
    
    # Display in columns
    col1, col2 = st.columns([1, 2])
    
    with col1:
        # Use a combination of emojis to create our sea captain
        if mood_name == "Calm Waters":
            captain_emoji = "👨‍✈️"
            ship_emoji = "🚢"
        elif mood_name == "Steady Seas":
            captain_emoji = "👨‍✈️"
            ship_emoji = "⛴️"
        elif mood_name == "Choppy Waters":
            captain_emoji = "🧔‍♂️"
            ship_emoji = "🛥️"
        elif mood_name == "Rough Seas":
            captain_emoji = "😬"
            ship_emoji = "⛵"
        else:  # Perfect Storm
            captain_emoji = "😱"
            ship_emoji = "🌊"
        
        # Create our sea captain display using emojis (much more compatible)
        st.markdown(f"""
        <div style="text-align: center; padding: 10px; border: 1px solid {mood_color}; border-radius: 10px; margin-bottom: 10px;">
            <div style="font-size: 48px;">{captain_emoji}</div>
            <div style="font-size: 32px;">{ship_emoji}</div>
            <div style="font-weight: bold; color: {mood_color};">Sea Captain</div>
            <div style="font-style: italic; font-size: 12px; margin-top: 5px;">"{get_captain_quote(mood_name)}"</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        # Display mood gauge with custom styling (smaller)
        st.markdown(f"""
        <div style="border:2px solid {mood_color}; border-radius:10px; padding:8px; margin-bottom:8px">
            <h4 style="color:{mood_color}; margin-top:0; margin-bottom:5px">Market Mood: {mood_name} {mood_emoji}</h4>
            <p style="font-size:0.9em; margin-bottom:5px">{mood_desc}</p>
            <div style="background-color:#e0e0e0; border-radius:5px; height:15px; width:100%">
                <div style="background-color:{mood_color}; width:{volatility_score}%; height:15px; border-radius:5px"></div>
            </div>
            <div style="display:flex; justify-content:space-between; margin-top:3px; font-size:0.8em">
                <span>Calm</span>
                <span>Volatile</span>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        # Additional analytics (more compact)
        st.markdown(f"#### Captain's Log: {asset_name}")
        
        if len(data) > 1:
            # Calculate recent performance
            if 'Close' in data.columns:
                recent_change = ((data['Close'].iloc[-1] / data['Close'].iloc[-2]) - 1) * 100
                max_price = data['High'].max()
                min_price = data['Low'].min()
                current_price = data['Close'].iloc[-1]
            else:
                recent_change = ((data['close_price'].iloc[-1] / data['close_price'].iloc[-2]) - 1) * 100
                max_price = data['high_price'].max()
                min_price = data['low_price'].min()
                current_price = data['close_price'].iloc[-1]
            
            # Display metrics in a more compact layout
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric(
                    "Recent Change",
                    f"{recent_change:.2f}%",
                    delta=f"{recent_change:.2f}%",
                    delta_color="inverse" if recent_change < 0 else "normal"
                )
            
            # Distance from high and low
            from_high = ((current_price / max_price) - 1) * 100
            from_low = ((current_price / min_price) - 1) * 100
            
            with col2:
                st.metric("From High", f"{from_high:.2f}%")
            with col3:
                st.metric("From Low", f"{from_low:.2f}%")
        else:
            st.info("Not enough data to analyze recent performance")

def get_captain_quote(mood):
    """
    Get a quote from the captain based on mood
    
    Parameters:
    mood (str): Mood name
    
    Returns:
    str: Captain's quote
    """
    if mood == "Calm Waters":
        quotes = [
            "Smooth sailing ahead!",
            "Clear skies and gentle winds!",
            "A perfect day for cruising!"
        ]
    elif mood == "Steady Seas":
        quotes = [
            "Good weather for sailing!",
            "Steady as she goes!",
            "The voyage looks promising!"
        ]
    elif mood == "Choppy Waters":
        quotes = [
            "Keep an eye on those clouds!",
            "We might see some waves ahead!",
            "Better check the rigging!"
        ]
    elif mood == "Rough Seas":
        quotes = [
            "Batten down the hatches!",
            "Rough waters ahead!",
            "Hold fast to the helm!"
        ]
    else:  # Perfect Storm
        quotes = [
            "ABANDON SHIP!",
            "We're heading into a maelstrom!",
            "Man the lifeboats!"
        ]
    
    # Return a random quote from the list
    import random
    return random.choice(quotes)