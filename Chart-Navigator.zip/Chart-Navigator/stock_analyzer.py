import yfinance as yf
import pandas as pd
import streamlit as st
from db_utils import (
    save_search_history, get_cached_stock_data, cache_stock_data,
    get_cached_company_info, cache_company_info
)

@st.cache_data(ttl=3600)  # Cache data for 1 hour
def get_stock_data(ticker, period="1y", interval="1d"):
    """
    Fetch historical stock data for the given ticker
    
    Parameters:
    ticker (str): Stock symbol
    period (str): Time period - 1d, 5d, 1mo, 3mo, 6mo, 1y, 2y, 5y, 10y, ytd, max
    interval (str): Data interval - 1m, 2m, 5m, 15m, 30m, 60m, 90m, 1h, 1d, 5d, 1wk, 1mo, 3mo
    
    Returns:
    DataFrame: Historical stock data
    """
    try:
        # Track user search
        save_search_history(ticker)
        
        # Try to get data from cache first (for daily intervals)
        if interval == "1d" and period in ["1mo", "3mo", "6mo", "1y"]:
            # Calculate days based on period
            days_mapping = {"1mo": 30, "3mo": 90, "6mo": 180, "1y": 365}
            days = days_mapping.get(period, 30)
            
            cached_data = get_cached_stock_data(ticker, days=days)
            if cached_data is not None and not cached_data.empty:
                return cached_data
        
        # If not in cache or not cacheable, fetch from API
        stock = yf.Ticker(ticker)
        data = stock.history(period=period, interval=interval)
        
        if data.empty:
            return None
        
        # For hourly intervals, ensure we don't request too much data
        if interval == "1h" and period in ["2y", "5y", "10y", "max"]:
            # Limit to 730 days (2 years) for hourly data to avoid excessive data
            st.warning("For hourly data, period is limited to 2 years maximum")
            period = "2y"
            data = stock.history(period=period, interval=interval)
        
        # Reset index to make Date a column
        data = data.reset_index()
        
        # Ensure the datetime column name is consistent (adjust based on interval)
        if 'Datetime' in data.columns:
            data = data.rename(columns={'Datetime': 'Date'})
        
        # Calculate additional metrics
        if len(data) > 1:
            # Calculate returns
            return_column_name = 'Hourly_Return' if interval == "1h" else 'Daily_Return'
            data[return_column_name] = data['Close'].pct_change() * 100
            
            # Calculate moving averages - adjust window size for different intervals
            if interval == "1h":
                # For hourly data, use smaller windows
                data['MA50'] = data['Close'].rolling(window=20).mean()  # ~1 trading day
                data['MA200'] = data['Close'].rolling(window=100).mean()  # ~1 trading week
            else:
                data['MA50'] = data['Close'].rolling(window=50).mean()
                data['MA200'] = data['Close'].rolling(window=200).mean()
        
        # Cache data for future use (only for daily intervals)
        if interval == "1d":
            cache_stock_data(ticker, data)
        
        return data
    except Exception as e:
        st.error(f"Error fetching stock data: {str(e)}")
        return None

@st.cache_data(ttl=86400)  # Cache for 24 hours
def get_company_info(ticker):
    """
    Fetch company information for the given ticker
    
    Parameters:
    ticker (str): Stock symbol
    
    Returns:
    dict: Company information
    """
    try:
        # Try to get from cache first
        cached_info = get_cached_company_info(ticker)
        if cached_info:
            return cached_info
            
        # If not in cache, fetch from API
        stock = yf.Ticker(ticker)
        info = stock.info
        
        # Extract relevant company information
        company_info = {
            'name': info.get('shortName', ticker),
            'sector': info.get('sector', 'N/A'),
            'industry': info.get('industry', 'N/A'),
            'country': info.get('country', 'N/A'),
            'website': info.get('website', 'N/A'),
            'logo_url': info.get('logo_url', ''),
            'long_business_summary': info.get('longBusinessSummary', 'No description available')
        }
        
        # Cache for future use
        cache_company_info(ticker, company_info)
        
        return company_info
    except Exception as e:
        st.error(f"Error fetching company info: {str(e)}")
        return None

@st.cache_data(ttl=3600)  # Cache for 1 hour
def get_key_metrics(ticker):
    """
    Fetch key financial metrics for the given ticker
    
    Parameters:
    ticker (str): Stock symbol
    
    Returns:
    dict: Key financial metrics
    """
    try:
        stock = yf.Ticker(ticker)
        info = stock.info
        
        # Extract key metrics
        metrics = {
            # Price metrics
            'currentPrice': info.get('currentPrice', info.get('regularMarketPrice', 0)),
            'previousClose': info.get('previousClose', 0),
            'open': info.get('open', 0),
            'dayLow': info.get('dayLow', 0),
            'dayHigh': info.get('dayHigh', 0),
            'fiftyTwoWeekLow': info.get('fiftyTwoWeekLow', 0),
            'fiftyTwoWeekHigh': info.get('fiftyTwoWeekHigh', 0),
            
            # Company valuation metrics
            'marketCap': info.get('marketCap', 0),
            'enterpriseValue': info.get('enterpriseValue', 0),
            
            # Financial ratios
            'trailingPE': info.get('trailingPE', 0),
            'forwardPE': info.get('forwardPE', 0),
            'pegRatio': info.get('pegRatio', 0),
            'priceToBook': info.get('priceToBook', 0),
            'priceToSalesTrailing12Months': info.get('priceToSalesTrailing12Months', 0),
            
            # Profitability metrics
            'profitMargins': info.get('profitMargins', 0),
            'returnOnEquity': info.get('returnOnEquity', 0),
            'returnOnAssets': info.get('returnOnAssets', 0),
            
            # Dividend metrics
            'dividendYield': info.get('dividendYield', 0),
            'dividendRate': info.get('dividendRate', 0),
            
            # Other metrics
            'beta': info.get('beta', 0),
            'trailingEps': info.get('trailingEps', 0),
            'forwardEps': info.get('forwardEps', 0),
            'averageVolume': info.get('averageVolume', 0)
        }
        
        return metrics
    except Exception as e:
        st.error(f"Error fetching key metrics: {str(e)}")
        return None

@st.cache_data(ttl=86400)  # Cache for 24 hours
def get_financial_data(ticker):
    """
    Fetch financial statement data for the given ticker
    
    Parameters:
    ticker (str): Stock symbol
    
    Returns:
    tuple: (income_statement, balance_sheet, cash_flow)
    """
    try:
        stock = yf.Ticker(ticker)
        
        # Get financial statements
        income_statement = stock.financials
        balance_sheet = stock.balance_sheet
        cash_flow = stock.cashflow
        
        return (income_statement, balance_sheet, cash_flow)
    except Exception as e:
        st.error(f"Error fetching financial data: {str(e)}")
        return (None, None, None)
