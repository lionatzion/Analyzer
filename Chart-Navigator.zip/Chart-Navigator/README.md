# Chart Navigator

Chart Navigator is a comprehensive financial analysis dashboard for analyzing both stock market data and cryptocurrency information through an interactive interface.

## Features

- **Stock Analysis:** Fetch and display real-time stock data from Yahoo Finance
- **Cryptocurrency Analysis:** Get cryptocurrency data via CoinMarketCap API
- **Interactive Charts:** Price history, volume, and financial metrics visualizations
- **Market Mood Indicator:** Visual indicator showing market volatility with animated sea captain mascot
- **User Favorites:** Save your favorite stocks and cryptocurrencies for quick access
- **Search History:** Keep track of your recent searches
- **Consistent Color Scheme:** Red for negative values, green for positive throughout the application

## Technologies Used

- Python
- Streamlit
- Pandas
- Plotly
- SQLAlchemy (PostgreSQL database)
- Yahoo Finance API
- CoinMarketCap API

## Getting Started

1. Clone this repository
2. Install dependencies: `pip install -r requirements.txt`
3. Set up your CoinMarketCap API key as an environment variable: `COINMARKETCAP_API_KEY`
4. Run the application: `streamlit run app.py`

## Screenshots

(Add screenshots here)

## License

MIT
