import streamlit as st
import pandas as pd
import time
import os
from datetime import datetime

from stock_analyzer import get_stock_data, get_company_info, get_key_metrics
from crypto_analyzer import get_crypto_data, get_crypto_info, get_top_cryptocurrencies
from chart_generator import (
    create_price_chart, create_volume_chart, create_metrics_charts,
    create_crypto_price_chart, create_crypto_volume_chart, create_crypto_metrics_chart
)
from utils import format_number, validate_ticker, handle_error
from db_utils import (
    get_recent_searches, get_favorites, add_favorite,
    remove_favorite, is_favorite
)
from market_mood import display_market_mood

# Page configuration
st.set_page_config(
    page_title="Chart Navigator",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# App title and description
st.title("📈 Chart Navigator")
st.markdown("### Financial Analysis Dashboard - Analyze real-time stock and cryptocurrency data")

# Sidebar for user input
with st.sidebar:
    # Asset type selection (Stocks or Crypto)
    asset_type = st.radio(
        "Select Asset Type",
        ["Stocks", "Cryptocurrencies"],
        key="asset_type"
    )
    
    # Initialize variables
    ticker = None
    symbol = None
    period = "1y"
    interval = "1d"  # Default interval for stocks
    days = 30  # For crypto API
    
    if asset_type == "Stocks":
        st.header("Stock Selection")
        
        # Default popular stocks
        popular_tickers = {
            "Apple": "AAPL",
            "Google": "GOOGL",
            "Microsoft": "MSFT",
            "Amazon": "AMZN",
            "Tesla": "TSLA",
            "Meta": "META",
            "Netflix": "NFLX"
        }
        
        # User can select from popular stocks or enter their own
        selection_method = st.radio(
            "Select a stock:",
            ["Choose from popular stocks", "Enter stock symbol"],
            key="stock_selection_method"
        )
        
        if selection_method == "Choose from popular stocks":
            selected_company = st.selectbox(
                "Select a company:",
                list(popular_tickers.keys()),
                key="stock_company"
            )
            ticker = popular_tickers[selected_company]
        else:
            ticker = st.text_input("Enter stock symbol (e.g., AAPL):", value="AAPL").upper()
        
        # Time period selection
        period_options = {
            "1 Month": "1mo",
            "3 Months": "3mo",
            "6 Months": "6mo",
            "Year to Date": "ytd",
            "1 Year": "1y",
            "5 Years": "5y",
            "Max": "max"
        }
        
        selected_period = st.selectbox(
            "Select time period:",
            list(period_options.keys()),
            key="stock_period"
        )
        period = period_options[selected_period]
        
        # Interval selection
        interval_options = {
            "1 Hour": "1h",
            "1 Day": "1d",
            "1 Week": "1wk",
            "1 Month": "1mo"
        }
        
        selected_interval = st.selectbox(
            "Select interval:",
            list(interval_options.keys()),
            key="stock_interval"
        )
        interval = interval_options[selected_interval]
    
    else:  # Cryptocurrency selection
        st.header("Cryptocurrency Selection")
        
        # Check if API Key is set
        coinmarketcap_api_key = os.environ.get('COINMARKETCAP_API_KEY')
        if not coinmarketcap_api_key:
            st.error("CoinMarketCap API Key is not set. Please set the COINMARKETCAP_API_KEY environment variable.")
            st.info("You can get a free API key from [CoinMarketCap](https://coinmarketcap.com/api/)")
            
            # Allow user to enter API key
            api_key = st.text_input("Enter your CoinMarketCap API Key:", type="password")
            if api_key:
                os.environ['COINMARKETCAP_API_KEY'] = api_key
                st.success("API Key set successfully! Please refresh the page.")
                st.rerun()
        
        # Default popular cryptocurrencies
        try:
            # Try to get top cryptocurrencies
            top_cryptos = get_top_cryptocurrencies(limit=10)
            if top_cryptos:
                popular_cryptos = {crypto['name']: crypto['symbol'] for crypto in top_cryptos}
            else:
                # Fallback to default list
                popular_cryptos = {
                    "Bitcoin": "BTC",
                    "Ethereum": "ETH",
                    "Binance Coin": "BNB",
                    "Cardano": "ADA",
                    "Solana": "SOL",
                    "XRP": "XRP",
                    "Dogecoin": "DOGE"
                }
        except Exception as e:
            st.warning(f"Could not fetch top cryptocurrencies: {str(e)}")
            # Fallback to default list
            popular_cryptos = {
                "Bitcoin": "BTC",
                "Ethereum": "ETH",
                "Binance Coin": "BNB",
                "Cardano": "ADA",
                "Solana": "SOL",
                "XRP": "XRP",
                "Dogecoin": "DOGE"
            }
        
        # User can select from popular cryptocurrencies or enter their own
        crypto_selection_method = st.radio(
            "Select a cryptocurrency:",
            ["Choose from popular cryptocurrencies", "Enter crypto symbol"],
            key="crypto_selection_method"
        )
        
        if crypto_selection_method == "Choose from popular cryptocurrencies":
            selected_crypto = st.selectbox(
                "Select a cryptocurrency:",
                list(popular_cryptos.keys()),
                key="crypto_name"
            )
            symbol = popular_cryptos[selected_crypto]
        else:
            symbol = st.text_input("Enter crypto symbol (e.g., BTC):", value="BTC").upper()
        
        # Time period selection for crypto
        period_options = {
            "7 Days": 7,
            "14 Days": 14,
            "30 Days": 30,
            "90 Days": 90,
            "180 Days": 180,
            "1 Year": 365
        }
        
        selected_period = st.selectbox(
            "Select time period:",
            list(period_options.keys()),
            key="crypto_period"
        )
        days = period_options[selected_period]
    
    # Recent searches section
    st.markdown("---")
    st.markdown("### Recent Searches")
    try:
        recent_searches = get_recent_searches(limit=5)
        if recent_searches:
            # Get unique searches (to avoid duplicate keys)
            unique_searches = []
            for search in recent_searches:
                if search not in unique_searches:
                    unique_searches.append(search)
            
            # Create buttons for each unique search
            for i, search in enumerate(unique_searches):
                if st.button(f"{search}", key=f"recent_{i}_{search}"):
                    ticker = search
                    st.rerun()
        else:
            st.write("No recent searches yet.")
    except Exception as e:
        st.error(f"Error loading recent searches: {str(e)}")
        st.write("No recent searches available.")
    
    # Favorites section
    st.markdown("---")
    st.markdown("### Favorites")
    try:
        favorites = get_favorites()
        if favorites:
            for i, fav in enumerate(favorites):
                if st.button(f"⭐ {fav['ticker']} - {fav['name']}", key=f"fav_{i}_{fav['ticker']}"):
                    ticker = fav['ticker']
                    st.rerun()
        else:
            st.write("No favorites yet. Add some by clicking the '☆ Add' button.")
    except Exception as e:
        st.error(f"Error loading favorites: {str(e)}")
        st.write("No favorites available.")
    
    st.markdown("---")
    st.markdown("### About")
    st.markdown("This app fetches real-time stock data from Yahoo Finance API and cryptocurrency data from CoinMarketCap API, displaying interactive charts and metrics.")

# Main content
if asset_type == "Stocks" and ticker:
    # Validate the ticker
    is_valid, message = validate_ticker(ticker)
    
    if not is_valid:
        st.error(message)
    else:
        try:
            # Loading state
            with st.spinner(f"Fetching data for {ticker}..."):
                # Get stock data
                stock_data = get_stock_data(ticker, period, interval)
                company_info = get_company_info(ticker)
                metrics = get_key_metrics(ticker)
                
# Debug section removed for production
                
                if stock_data is None or company_info is None or metrics is None:
                    st.error(f"Failed to fetch data for {ticker}. Please try another stock symbol.")
                else:
                    # Company header with info
                    col1, col2, col3 = st.columns([1, 2.5, 0.5])
                    
                    with col1:
                        logo_url = company_info.get('logo_url')
                        if logo_url and logo_url.strip():
                            try:
                                st.image(logo_url, width=100)
                            except Exception:
                                st.write("📈") # Fallback to an emoji if image can't be displayed
                        else:
                            st.write("📈") # Show a chart emoji when no logo is available
                    
                    with col2:
                        st.subheader(f"{company_info.get('name', ticker)} ({ticker})")
                        st.markdown(f"**Sector:** {company_info.get('sector', 'N/A')} | **Industry:** {company_info.get('industry', 'N/A')}")
                        st.markdown(f"**{company_info.get('country', 'N/A')}** | {company_info.get('website', 'N/A')}")
                    
                    with col3:
                        # Check if this stock is already in favorites
                        is_fav = is_favorite(ticker)
                        
                        if is_fav:
                            # Star icon (filled) if in favorites
                            if st.button("⭐ Remove", key="remove_fav"):
                                remove_favorite(ticker)
                                st.success(f"Removed {ticker} from favorites!")
                                st.rerun()
                        else:
                            # Add to favorites button
                            if st.button("☆ Add", key="add_fav"):
                                add_favorite(ticker, company_info.get('name', ticker))
                                st.success(f"Added {ticker} to favorites!")
                                st.rerun()
                    
                    # Current price metrics
                    st.markdown("---")
                    
                    last_price = metrics.get('currentPrice', 0)
                    prev_close = metrics.get('previousClose', 0)
                    price_change = last_price - prev_close
                    price_change_percent = (price_change / prev_close) * 100 if prev_close else 0
                    
                    col1, col2, col3, col4 = st.columns(4)
                    
                    with col1:
                        # Custom styling for prices
                        price_color = "#ef5350" if price_change < 0 else "#26a69a"  # Red if negative, green if positive
                        
                        # Instead of using st.metric, we'll create our own styled version
                        st.markdown("**Current Price**")
                        
                        # Style both the price and the change percentage with the same color
                        st.markdown(f"""
                        <div style="font-size: 1.5rem; font-weight: bold; color: {price_color};">
                            ${format_number(last_price, 2)}
                        </div>
                        <div style="color: {price_color}; margin-top: -0.5rem;">
                            {format_number(price_change, 2)} ({format_number(price_change_percent, 2)}%)
                        </div>
                        """, unsafe_allow_html=True)
                    
                    with col2:
                        st.metric(
                            "Market Cap",
                            f"${format_number(metrics.get('marketCap', 0), 2, True)}"
                        )
                    
                    with col3:
                        st.metric(
                            "P/E Ratio",
                            format_number(metrics.get('trailingPE', 0), 2)
                        )
                    
                    with col4:
                        st.metric(
                            "52 Week Range",
                            f"${format_number(metrics.get('fiftyTwoWeekLow', 0), 2)} - ${format_number(metrics.get('fiftyTwoWeekHigh', 0), 2)}"
                        )
                    
                    # Market Mood Indicator with Sea Captain
                    st.markdown("### Market Mood Indicator")
                    display_market_mood(stock_data, "stock", company_info.get('name', ticker))
                    
                    # Price chart
                    st.markdown("### Historical Price Chart")
                    price_chart = create_price_chart(stock_data, ticker)
                    st.plotly_chart(price_chart, use_container_width=True)
                    
                    # Volume chart
                    st.markdown("### Trading Volume")
                    volume_chart = create_volume_chart(stock_data, ticker)
                    st.plotly_chart(volume_chart, use_container_width=True)
                    
                    # Key financial metrics
                    st.markdown("### Key Financial Metrics")
                    
                    # Financial metrics in a table
                    metrics_df = pd.DataFrame({
                        'Metric': [
                            'EPS (TTM)', 'Forward P/E', 'PEG Ratio', 'Price-to-Book', 
                            'Price-to-Sales', 'Dividend Yield', 'Profit Margin', 'ROE',
                            'Beta', 'Average Volume'
                        ],
                        'Value': [
                            f"${format_number(metrics.get('trailingEps', 0), 2)}",
                            format_number(metrics.get('forwardPE', 0), 2),
                            format_number(metrics.get('pegRatio', 0), 2),
                            format_number(metrics.get('priceToBook', 0), 2),
                            format_number(metrics.get('priceToSalesTrailing12Months', 0), 2),
                            f"{format_number(metrics.get('dividendYield', 0), 2)}%" if metrics.get('dividendYield') else 'N/A',
                            f"{format_number(metrics.get('profitMargins', 0) * 100, 2)}%",
                            f"{format_number(metrics.get('returnOnEquity', 0) * 100, 2)}%",
                            format_number(metrics.get('beta', 0), 2),
                            f"{format_number(metrics.get('averageVolume', 0), 0, True)}"
                        ]
                    })
                    
                    col1, col2 = st.columns([1, 2])
                    
                    with col1:
                        st.dataframe(metrics_df, hide_index=True, use_container_width=True)
                    
                    with col2:
                        metrics_charts = create_metrics_charts(ticker)
                        st.plotly_chart(metrics_charts, use_container_width=True)
                    
                    # Company description
                    st.markdown("### Company Description")
                    st.write(company_info.get('long_business_summary', 'No description available.'))
                    
        except Exception as e:
            handle_error("An error occurred while processing the stock data", e)

# Cryptocurrency content
elif asset_type == "Cryptocurrencies" and symbol:
    # Check if API key is set
    api_key = os.environ.get('COINMARKETCAP_API_KEY')
    if not api_key:
        st.error("CoinMarketCap API Key is required to view cryptocurrency data")
    else:
        try:
            # Loading state
            with st.spinner(f"Fetching data for {symbol}..."):
                # Get crypto data
                crypto_data = get_crypto_data(symbol, period=days)
                crypto_info = get_crypto_info(symbol)
                
# Debug section removed for production
                
                if crypto_data is None or crypto_info is None:
                    st.error(f"Failed to fetch data for {symbol}. Please try another cryptocurrency symbol.")
                else:
                    # Crypto header with info
                    col1, col2, col3 = st.columns([1, 2.5, 0.5])
                    
                    with col1:
                        # Crypto doesn't usually have logo URLs in the API, use emoji instead
                        st.write("💰")
                    
                    with col2:
                        st.subheader(f"{crypto_info.get('name', symbol)} ({symbol})")
                    
                    with col3:
                        # Check if this crypto is already in favorites
                        is_fav = is_favorite(symbol)
                        
                        if is_fav:
                            # Star icon (filled) if in favorites
                            if st.button("⭐ Remove", key="remove_fav"):
                                remove_favorite(symbol)
                                st.success(f"Removed {symbol} from favorites!")
                                st.rerun()
                        else:
                            # Add to favorites button
                            if st.button("☆ Add", key="add_fav"):
                                add_favorite(symbol, crypto_info.get('name', symbol))
                                st.success(f"Added {symbol} to favorites!")
                                st.rerun()
                    
                    # Current price metrics
                    st.markdown("---")
                    
                    price = crypto_info.get('price', 0)
                    percent_change_24h = crypto_info.get('percent_change_24h', 0)
                    
                    col1, col2, col3, col4 = st.columns(4)
                    
                    with col1:
                        # Custom styling for crypto prices
                        price_color = "#ef5350" if percent_change_24h < 0 else "#26a69a"  # Red if negative, green if positive
                        
                        # Instead of using st.metric, we'll create our own styled version
                        st.markdown("**Current Price**")
                        
                        # Style both the price and the change percentage with the same color
                        st.markdown(f"""
                        <div style="font-size: 1.5rem; font-weight: bold; color: {price_color};">
                            ${format_number(price, 2)}
                        </div>
                        <div style="color: {price_color}; margin-top: -0.5rem;">
                            {format_number(percent_change_24h, 2)}%
                        </div>
                        """, unsafe_allow_html=True)
                    
                    with col2:
                        st.metric(
                            "Market Cap",
                            f"${format_number(crypto_info.get('market_cap', 0), 2, True)}"
                        )
                    
                    with col3:
                        st.metric(
                            "24h Volume",
                            f"${format_number(crypto_info.get('volume_24h', 0), 2, True)}"
                        )
                    
                    with col4:
                        # Get the 1h percent change
                        percent_change_1h = crypto_info.get('percent_change_1h', 0)
                        
                        # Custom styling for 1h change
                        change_color = "#ef5350" if percent_change_1h < 0 else "#26a69a"  # Red if negative, green if positive
                        
                        # Instead of using st.metric, we'll create our own styled version
                        st.markdown("**1h Change**")
                        
                        # Style the change percentage with the appropriate color
                        st.markdown(f"""
                        <div style="font-size: 1.5rem; font-weight: bold; color: {change_color};">
                            {format_number(percent_change_1h, 2)}%
                        </div>
                        """, unsafe_allow_html=True)
                    
                    # Market Mood Indicator with Sea Captain
                    st.markdown("### Market Mood Indicator")
                    display_market_mood(crypto_data, "crypto", crypto_info.get('name', symbol))
                    
                    # Price chart
                    st.markdown("### Historical Price Chart")
                    price_chart = create_crypto_price_chart(crypto_data, symbol)
                    st.plotly_chart(price_chart, use_container_width=True)
                    
                    # Volume chart
                    st.markdown("### Trading Volume")
                    volume_chart = create_crypto_volume_chart(crypto_data, symbol)
                    st.plotly_chart(volume_chart, use_container_width=True)
                    
                    # Price change metrics
                    st.markdown("### Price Change Analysis")
                    metrics_chart = create_crypto_metrics_chart(crypto_info)
                    st.plotly_chart(metrics_chart, use_container_width=True)
                    
                    # Price metrics in a table
                    # Convert datetime to string to avoid Arrow serialization issues
                    last_updated = crypto_info.get('last_updated', 'N/A')
                    if isinstance(last_updated, datetime):
                        last_updated = last_updated.strftime('%Y-%m-%d %H:%M:%S')
                        
                    metrics_df = pd.DataFrame({
                        'Metric': [
                            'Current Price', 'Market Cap', '24h Volume',
                            '1h Change', '24h Change', '7d Change',
                            'Last Updated'
                        ],
                        'Value': [
                            f"${format_number(crypto_info.get('price', 0), 2)}",
                            f"${format_number(crypto_info.get('market_cap', 0), 2, True)}",
                            f"${format_number(crypto_info.get('volume_24h', 0), 2, True)}",
                            f"{format_number(crypto_info.get('percent_change_1h', 0), 2)}%",
                            f"{format_number(crypto_info.get('percent_change_24h', 0), 2)}%",
                            f"{format_number(crypto_info.get('percent_change_7d', 0), 2)}%",
                            last_updated
                        ]
                    })
                    
                    st.dataframe(metrics_df, hide_index=True, use_container_width=True)
                    
        except Exception as e:
            handle_error("An error occurred while processing the cryptocurrency data", e)
