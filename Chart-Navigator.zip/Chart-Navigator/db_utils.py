from datetime import datetime, timedelta
import pandas as pd
import time
from sqlalchemy.exc import OperationalError
from db_models import (
    get_db_session, User, Favorite, SearchHistory, 
    StockData, CompanyInfo
)

def db_operation_with_retry(operation_func, max_retries=3, retry_delay=0.5):
    """
    Execute a database operation with retry logic
    
    Parameters:
    operation_func (function): Function to execute that takes a db session as parameter
    max_retries (int): Maximum number of retry attempts
    retry_delay (float): Delay between retries in seconds
    
    Returns:
    Any: Result of the operation function, or None if all retries fail
    """
    retries = 0
    last_error = None
    
    while retries < max_retries:
        db = get_db_session()
        try:
            result = operation_func(db)
            return result
        except OperationalError as e:
            last_error = e
            db.rollback()
            print(f"Database operation error (retry {retries+1}/{max_retries}): {str(e)}")
            retries += 1
            time.sleep(retry_delay)
        except Exception as e:
            db.rollback()
            print(f"Error in database operation: {str(e)}")
            return None
        finally:
            db.close()
    
    print(f"Failed after {max_retries} retries. Last error: {str(last_error)}")
    return None

def save_search_history(ticker, user_id=1):
    """
    Save a search to the user's search history
    
    Parameters:
    ticker (str): Stock symbol
    user_id (int): User ID (default is 1 for anonymous/default user)
    """
    def _operation(db):
        # Check if user exists, if not create a default user
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            user = User(id=1, username="default_user", email="default@example.com")
            db.add(user)
            db.commit()
        
        # Add search history
        search = SearchHistory(
            user_id=user_id,
            ticker=ticker.upper()
        )
        db.add(search)
        db.commit()
        return True
    
    try:
        return db_operation_with_retry(_operation)
    except Exception as e:
        print(f"Error saving search history: {str(e)}")
        return False

def get_recent_searches(limit=10, user_id=1):
    """
    Get the user's recent searches
    
    Parameters:
    limit (int): Maximum number of searches to return
    user_id (int): User ID
    
    Returns:
    list: List of recent searches
    """
    def _operation(db):
        searches = (
            db.query(SearchHistory)
            .filter(SearchHistory.user_id == user_id)
            .order_by(SearchHistory.searched_at.desc())
            .limit(limit)
            .all()
        )
        
        # Convert to list of tickers
        return [search.ticker for search in searches]
    
    try:
        results = db_operation_with_retry(_operation)
        return results if results is not None else []
    except Exception as e:
        print(f"Error getting recent searches: {str(e)}")
        return []

def add_favorite(ticker, name, user_id=1, notes=None):
    """
    Add a stock to user's favorites
    
    Parameters:
    ticker (str): Stock symbol
    name (str): Company name
    user_id (int): User ID
    notes (str): Optional notes
    
    Returns:
    bool: Success status
    """
    def _operation(db):
        # Check if user exists, if not create a default user
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            user = User(id=1, username="default_user", email="default@example.com")
            db.add(user)
            db.commit()
        
        # Check if already a favorite
        existing = (
            db.query(Favorite)
            .filter(Favorite.user_id == user_id, Favorite.ticker == ticker.upper())
            .first()
        )
        
        if existing:
            # Update notes if provided
            if notes:
                existing.notes = notes
                db.commit()
            return True
        
        # Add new favorite
        favorite = Favorite(
            user_id=user_id,
            ticker=ticker.upper(),
            name=name,
            notes=notes
        )
        db.add(favorite)
        db.commit()
        return True
    
    try:
        result = db_operation_with_retry(_operation)
        return True if result else False
    except Exception as e:
        print(f"Error adding favorite: {str(e)}")
        return False

def remove_favorite(ticker, user_id=1):
    """
    Remove a stock from user's favorites
    
    Parameters:
    ticker (str): Stock symbol
    user_id (int): User ID
    
    Returns:
    bool: Success status
    """
    def _operation(db):
        favorite = (
            db.query(Favorite)
            .filter(Favorite.user_id == user_id, Favorite.ticker == ticker.upper())
            .first()
        )
        
        if favorite:
            db.delete(favorite)
            db.commit()
            return True
        return False
    
    try:
        result = db_operation_with_retry(_operation)
        return True if result else False
    except Exception as e:
        print(f"Error removing favorite: {str(e)}")
        return False

def get_favorites(user_id=1):
    """
    Get all favorites for a user
    
    Parameters:
    user_id (int): User ID
    
    Returns:
    list: List of favorite stocks
    """
    def _operation(db):
        favorites = (
            db.query(Favorite)
            .filter(Favorite.user_id == user_id)
            .order_by(Favorite.added_at.desc())
            .all()
        )
        
        # Convert to list of dictionaries
        return [{
            'ticker': fav.ticker,
            'name': fav.name,
            'added_at': fav.added_at,
            'notes': fav.notes
        } for fav in favorites]
    
    try:
        results = db_operation_with_retry(_operation)
        return results if results is not None else []
    except Exception as e:
        print(f"Error getting favorites: {str(e)}")
        return []

def is_favorite(ticker, user_id=1):
    """
    Check if a stock is in user's favorites
    
    Parameters:
    ticker (str): Stock symbol
    user_id (int): User ID
    
    Returns:
    bool: True if in favorites
    """
    def _operation(db):
        favorite = (
            db.query(Favorite)
            .filter(Favorite.user_id == user_id, Favorite.ticker == ticker.upper())
            .first()
        )
        
        return favorite is not None
    
    try:
        result = db_operation_with_retry(_operation)
        return True if result else False
    except Exception as e:
        print(f"Error checking favorite status: {str(e)}")
        return False

def cache_company_info(ticker, company_info):
    """
    Cache company information in the database
    
    Parameters:
    ticker (str): Stock symbol
    company_info (dict): Company information
    
    Returns:
    bool: Success status
    """
    db = get_db_session()
    try:
        # Check if company exists in database
        company = (
            db.query(CompanyInfo)
            .filter(CompanyInfo.ticker == ticker.upper())
            .first()
        )
        
        # Update or create
        if company:
            company.name = company_info.get('name', ticker)
            company.sector = company_info.get('sector', 'N/A')
            company.industry = company_info.get('industry', 'N/A')
            company.country = company_info.get('country', 'N/A')
            company.website = company_info.get('website', 'N/A')
            company.description = company_info.get('long_business_summary', '')
            company.logo_url = company_info.get('logo_url', '')
            company.updated_at = datetime.utcnow()
        else:
            company = CompanyInfo(
                ticker=ticker.upper(),
                name=company_info.get('name', ticker),
                sector=company_info.get('sector', 'N/A'),
                industry=company_info.get('industry', 'N/A'),
                country=company_info.get('country', 'N/A'),
                website=company_info.get('website', 'N/A'),
                description=company_info.get('long_business_summary', ''),
                logo_url=company_info.get('logo_url', ''),
            )
            db.add(company)
        
        db.commit()
        return True
    except Exception as e:
        db.rollback()
        print(f"Error caching company info: {str(e)}")
        return False
    finally:
        db.close()

def get_cached_company_info(ticker):
    """
    Get cached company information
    
    Parameters:
    ticker (str): Stock symbol
    
    Returns:
    dict: Company information
    """
    db = get_db_session()
    try:
        company = (
            db.query(CompanyInfo)
            .filter(CompanyInfo.ticker == ticker.upper())
            .first()
        )
        
        if company:
            # Check if data is fresh (less than 24 hours old)
            if datetime.utcnow() - company.updated_at < timedelta(hours=24):
                return {
                    'name': company.name,
                    'sector': company.sector,
                    'industry': company.industry,
                    'country': company.country,
                    'website': company.website,
                    'long_business_summary': company.description,
                    'logo_url': company.logo_url
                }
        
        return None
    except Exception as e:
        print(f"Error getting cached company info: {str(e)}")
        return None
    finally:
        db.close()

def cache_stock_data(ticker, stock_data):
    """
    Cache stock price data in the database
    
    Parameters:
    ticker (str): Stock symbol
    stock_data (DataFrame): Stock price data
    
    Returns:
    bool: Success status
    """
    if stock_data is None or stock_data.empty:
        return False
    
    db = get_db_session()
    try:
        # Delete existing data for this ticker (cache refresh)
        db.query(StockData).filter(StockData.ticker == ticker.upper()).delete()
        
        # Add new data
        for index, row in stock_data.iterrows():
            date = row['Date'] if isinstance(row['Date'], datetime) else pd.to_datetime(row['Date'])
            
            stock_price = StockData(
                ticker=ticker.upper(),
                date=date,
                open_price=float(row['Open']),
                high_price=float(row['High']),
                low_price=float(row['Low']),
                close_price=float(row['Close']),
                volume=int(row['Volume']),
            )
            db.add(stock_price)
        
        db.commit()
        return True
    except Exception as e:
        db.rollback()
        print(f"Error caching stock data: {str(e)}")
        return False
    finally:
        db.close()

def get_cached_stock_data(ticker, days=30):
    """
    Get cached stock price data
    
    Parameters:
    ticker (str): Stock symbol
    days (int): Number of days of data to return
    
    Returns:
    DataFrame: Stock price data
    """
    db = get_db_session()
    try:
        # Get data for last N days
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        
        # Query the database
        stock_data = (
            db.query(StockData)
            .filter(
                StockData.ticker == ticker.upper(),
                StockData.date >= cutoff_date
            )
            .order_by(StockData.date)
            .all()
        )
        
        # Check if we have fresh data (less than 24 hours old)
        if stock_data:
            latest_update = max(data.updated_at for data in stock_data)
            if datetime.utcnow() - latest_update > timedelta(hours=24):
                return None  # Data is stale
                
            # Convert to DataFrame
            df = pd.DataFrame([{
                'Date': data.date,
                'Open': data.open_price,
                'High': data.high_price,
                'Low': data.low_price,
                'Close': data.close_price,
                'Volume': data.volume
            } for data in stock_data])
            
            # Calculate additional metrics if there's enough data
            if len(df) > 1:
                df['Daily_Return'] = df['Close'].pct_change() * 100
                if len(df) >= 50:
                    df['MA50'] = df['Close'].rolling(window=50).mean()
                if len(df) >= 200:
                    df['MA200'] = df['Close'].rolling(window=200).mean()
                
            return df
            
        return None
    except Exception as e:
        print(f"Error getting cached stock data: {str(e)}")
        return None
    finally:
        db.close()

def init_user():
    """
    Initialize the default user if it doesn't exist
    """
    db = get_db_session()
    try:
        # Check if default user exists
        default_user = db.query(User).filter(User.id == 1).first()
        if not default_user:
            # Create default user
            default_user = User(
                id=1,
                username="default_user",
                email="default@example.com"
            )
            db.add(default_user)
            db.commit()
            print("Created default user.")
    except Exception as e:
        db.rollback()
        print(f"Error initializing user: {str(e)}")
    finally:
        db.close()