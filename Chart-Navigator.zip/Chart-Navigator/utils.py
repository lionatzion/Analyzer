import streamlit as st
import numpy as np
import pandas as pd
import yfinance as yf
import traceback

def format_number(value, decimal_places=2, use_suffix=False):
    """
    Format numbers with appropriate decimal places and optional suffixes
    
    Parameters:
    value (float): Number to format
    decimal_places (int): Number of decimal places to show
    use_suffix (bool): Whether to use K, M, B suffixes for thousands, millions, billions
    
    Returns:
    str: Formatted number
    """
    if value is None or np.isnan(value):
        return "N/A"
    
    if use_suffix:
        # Use suffix for large numbers
        if abs(value) >= 1e12:
            return f"{value / 1e12:.{decimal_places}f}T"
        elif abs(value) >= 1e9:
            return f"{value / 1e9:.{decimal_places}f}B"
        elif abs(value) >= 1e6:
            return f"{value / 1e6:.{decimal_places}f}M"
        elif abs(value) >= 1e3:
            return f"{value / 1e3:.{decimal_places}f}K"
    
    # Format with specified decimal places
    if decimal_places == 0:
        return f"{int(value):,}"
    else:
        return f"{value:,.{decimal_places}f}"

def validate_ticker(ticker):
    """
    Validate if a ticker symbol is valid
    
    Parameters:
    ticker (str): Stock symbol to validate
    
    Returns:
    tuple: (is_valid, message)
    """
    if not ticker or len(ticker.strip()) == 0:
        return False, "Please enter a stock symbol"
    
    try:
        # Try to get basic info about the ticker
        stock = yf.Ticker(ticker)
        info = stock.info
        
        # Check if we got valid data
        if 'regularMarketPrice' not in info and 'currentPrice' not in info:
            return False, f"Invalid stock symbol: {ticker}. Please enter a valid symbol."
        
        return True, "Valid ticker"
    except Exception as e:
        return False, f"Error validating ticker {ticker}: {str(e)}"

def handle_error(message, exception=None):
    """
    Handle and display error messages in the app
    
    Parameters:
    message (str): Error message to display
    exception (Exception): The exception that was caught
    """
    st.error(message)
    
    if exception:
        # Log detailed error for debugging
        st.expander("Error Details").write(str(exception))
        
        # Log to console for server-side debugging
        print(f"ERROR: {message}")
        print(traceback.format_exc())

def get_stock_news(ticker, limit=5):
    """
    Get recent news for a stock
    
    Parameters:
    ticker (str): Stock symbol
    limit (int): Maximum number of news items to return
    
    Returns:
    list: List of news item dictionaries
    """
    try:
        stock = yf.Ticker(ticker)
        news = stock.news
        
        if not news:
            return []
        
        # Limit number of news items
        limited_news = news[:limit]
        
        # Extract relevant information
        formatted_news = []
        for item in limited_news:
            formatted_news.append({
                'title': item.get('title', 'No title'),
                'link': item.get('link', '#'),
                'publisher': item.get('publisher', 'Unknown'),
                'published': pd.to_datetime(item.get('providerPublishTime', 0), unit='s')
            })
        
        return formatted_news
    except Exception as e:
        st.error(f"Error fetching news: {str(e)}")
        return []
