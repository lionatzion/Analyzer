import os
import sqlalchemy as sa
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Boolean, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime

# Get database URL from environment variables
DATABASE_URL = os.getenv("DATABASE_URL")

# Create database engine
engine = create_engine(DATABASE_URL)

# Create base class for ORM models
Base = declarative_base()

# Define User model (for future authentication/personalization features)
class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False)
    email = Column(String(100), unique=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    favorites = relationship("Favorite", back_populates="user", cascade="all, delete-orphan")
    search_history = relationship("SearchHistory", back_populates="user", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<User(username='{self.username}', email='{self.email}')>"


# Define Favorite model for saving favorite stocks
class Favorite(Base):
    __tablename__ = 'favorites'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    ticker = Column(String(20), nullable=False)  # Stock symbol
    name = Column(String(100))  # Company name
    added_at = Column(DateTime, default=datetime.utcnow)
    notes = Column(String(500))  # Optional user notes
    
    # Relationships
    user = relationship("User", back_populates="favorites")
    
    def __repr__(self):
        return f"<Favorite(ticker='{self.ticker}', name='{self.name}')>"


# Define SearchHistory model for tracking user searches
class SearchHistory(Base):
    __tablename__ = 'search_history'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    ticker = Column(String(20), nullable=False)
    searched_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="search_history")
    
    def __repr__(self):
        return f"<SearchHistory(ticker='{self.ticker}', searched_at='{self.searched_at}')>"


# Define StockData model for caching stock data
class StockData(Base):
    __tablename__ = 'stock_data'
    
    id = Column(Integer, primary_key=True)
    ticker = Column(String(20), nullable=False, index=True)
    date = Column(DateTime, nullable=False)
    open_price = Column(Float)
    high_price = Column(Float)
    low_price = Column(Float)
    close_price = Column(Float)
    volume = Column(Integer)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<StockData(ticker='{self.ticker}', date='{self.date}', close='{self.close_price}')>"


# Define CompanyInfo model for caching company information
class CompanyInfo(Base):
    __tablename__ = 'company_info'
    
    id = Column(Integer, primary_key=True)
    ticker = Column(String(20), nullable=False, unique=True)
    name = Column(String(100))
    sector = Column(String(100))
    industry = Column(String(100))
    country = Column(String(100))
    website = Column(String(255))
    description = Column(String(5000))
    logo_url = Column(String(255))
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<CompanyInfo(ticker='{self.ticker}', name='{self.name}')>"


# Define CryptoData model for caching cryptocurrency data
class CryptoData(Base):
    __tablename__ = 'crypto_data'
    
    id = Column(Integer, primary_key=True)
    symbol = Column(String(20), nullable=False, index=True)
    date = Column(DateTime, nullable=False)
    open_price = Column(Float)
    high_price = Column(Float)
    low_price = Column(Float)
    close_price = Column(Float)
    volume = Column(Float)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<CryptoData(symbol='{self.symbol}', date='{self.date}', close='{self.close_price}')>"


# Define CryptoInfo model for caching cryptocurrency information
class CryptoInfo(Base):
    __tablename__ = 'crypto_info'
    
    id = Column(Integer, primary_key=True)
    symbol = Column(String(20), nullable=False, unique=True)
    name = Column(String(100))
    price = Column(Float)
    volume_24h = Column(Float)
    market_cap = Column(Float)
    percent_change_1h = Column(Float)
    percent_change_24h = Column(Float)
    percent_change_7d = Column(Float)
    last_updated = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<CryptoInfo(symbol='{self.symbol}', name='{self.name}')>"


# Create all tables in the database
def create_tables():
    Base.metadata.create_all(engine)


# Create a session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


# Helper function to get a database session
def get_db_session():
    db = SessionLocal()
    try:
        return db
    except Exception as e:
        db.close()
        raise e


# Initialize the database (create tables if they don't exist)
def init_db():
    create_tables()
    print("Database tables created.")


# If run directly, initialize the database
if __name__ == "__main__":
    init_db()