import plotly.graph_objects as go
import plotly.express as px
import numpy as np
import pandas as pd
import yfinance as yf
import streamlit as st

def create_price_chart(data, ticker):
    """
    Create an interactive price chart with moving averages
    
    Parameters:
    data (DataFrame): Historical stock data
    ticker (str): Stock symbol
    
    Returns:
    Figure: Plotly figure object
    """
    if data is None or data.empty:
        return go.Figure()
    
    # Create figure
    fig = go.Figure()
    
    # Determine date column name (could be 'Date' or 'Datetime' depending on the data interval)
    date_col = None
    for col in ['Date', 'Datetime', 'date', 'datetime']:
        if col in data.columns:
            date_col = col
            break
            
    # If no date column found, use the index
    if date_col is None:
        # Convert index to a column if it's a DatetimeIndex
        if isinstance(data.index, pd.DatetimeIndex):
            data = data.reset_index()
            date_col = 'index'  # The default name when reset_index() converts the index
        else:
            # Create a basic index as a last resort
            date_col = 'x'
            data[date_col] = range(len(data))
    
    # Add candlestick chart
    fig.add_trace(
        go.Candlestick(
            x=data[date_col],
            open=data['Open'],
            high=data['High'],
            low=data['Low'],
            close=data['Close'],
            name=ticker,
            increasing_line_color='#26a69a',
            decreasing_line_color='#ef5350'
        )
    )
    
    # Add moving averages if available
    if 'MA50' in data.columns and not data['MA50'].isna().all():
        fig.add_trace(
            go.Scatter(
                x=data[date_col],
                y=data['MA50'],
                name='50-Day MA',
                line=dict(color='#2196f3', width=1.5)
            )
        )
    
    if 'MA200' in data.columns and not data['MA200'].isna().all():
        fig.add_trace(
            go.Scatter(
                x=data[date_col],
                y=data['MA200'],
                name='200-Day MA',
                line=dict(color='#ff9800', width=1.5)
            )
        )
    
    # Set layout
    fig.update_layout(
        title=f'{ticker} Historical Price',
        xaxis_title='Date',
        yaxis_title='Price (USD)',
        template='plotly_dark',
        xaxis_rangeslider_visible=False,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        ),
        height=500,
        margin=dict(l=20, r=20, t=50, b=20)
    )
    
    return fig

def create_volume_chart(data, ticker):
    """
    Create a volume chart for the stock
    
    Parameters:
    data (DataFrame): Historical stock data
    ticker (str): Stock symbol
    
    Returns:
    Figure: Plotly figure object
    """
    if data is None or data.empty:
        return go.Figure()
    
    # Determine date column name (could be 'Date' or 'Datetime' depending on the data interval)
    date_col = None
    for col in ['Date', 'Datetime', 'date', 'datetime']:
        if col in data.columns:
            date_col = col
            break
            
    # If no date column found, use the index
    if date_col is None:
        # Convert index to a column if it's a DatetimeIndex
        if isinstance(data.index, pd.DatetimeIndex):
            data = data.reset_index()
            date_col = 'index'  # The default name when reset_index() converts the index
        else:
            # Create a basic index as a last resort
            date_col = 'x'
            data[date_col] = range(len(data))
    
    # Create color array for volume bars (green for up days, red for down days)
    colors = ['#26a69a' if data['Close'].iloc[i] >= data['Open'].iloc[i] else '#ef5350' 
              for i in range(len(data))]
    
    # Create figure
    fig = go.Figure()
    
    # Add volume bars
    fig.add_trace(
        go.Bar(
            x=data[date_col],
            y=data['Volume'],
            marker_color=colors,
            name='Volume'
        )
    )
    
    # Set layout
    fig.update_layout(
        title=f'{ticker} Trading Volume',
        xaxis_title='Date',
        yaxis_title='Volume',
        template='plotly_dark',
        height=300,
        margin=dict(l=20, r=20, t=50, b=20)
    )
    
    return fig

@st.cache_data(ttl=3600)  # Cache for 1 hour
def create_metrics_charts(ticker):
    """
    Create charts for key financial metrics
    
    Parameters:
    ticker (str): Stock symbol
    
    Returns:
    Figure: Plotly figure object
    """
    try:
        stock = yf.Ticker(ticker)
        
        # Get quarterly financials
        quarterly_financials = stock.quarterly_financials
        
        if quarterly_financials is None or quarterly_financials.empty:
            # Create empty chart with message
            fig = go.Figure()
            fig.add_annotation(
                text="Financial data not available for this stock",
                xref="paper", yref="paper",
                x=0.5, y=0.5, showarrow=False,
                font=dict(size=16)
            )
            return fig
        
        # Extract key financial metrics (Revenue and Net Income)
        try:
            revenue = quarterly_financials.loc['Total Revenue']
            net_income = quarterly_financials.loc['Net Income']
            
            # Prepare data for chart
            dates = [date.strftime('%Y-%m-%d') for date in revenue.index]
            
            # Create figure with subplots
            fig = go.Figure()
            
            # Add Revenue trace
            fig.add_trace(
                go.Bar(
                    x=dates,
                    y=revenue.values / 1e6,  # Convert to millions
                    name='Revenue (M)',
                    marker_color='#2196f3'
                )
            )
            
            # Add Net Income trace
            fig.add_trace(
                go.Bar(
                    x=dates,
                    y=net_income.values / 1e6,  # Convert to millions
                    name='Net Income (M)',
                    marker_color='#4caf50'
                )
            )
            
            # Set layout
            fig.update_layout(
                title='Quarterly Financial Performance',
                xaxis_title='Quarter',
                yaxis_title='USD (Millions)',
                template='plotly_dark',
                barmode='group',
                legend=dict(
                    orientation="h",
                    yanchor="bottom",
                    y=1.02,
                    xanchor="right",
                    x=1
                ),
                height=350,
                margin=dict(l=20, r=20, t=50, b=20)
            )
            
            return fig
            
        except KeyError:
            # If specific metrics not found, show general financials
            metrics = quarterly_financials.iloc[:5]  # Get top 5 metrics
            
            # Prepare data
            dates = [date.strftime('%Y-%m-%d') for date in metrics.columns]
            
            # Create figure
            fig = go.Figure()
            
            # Add traces for each metric
            for i, metric in enumerate(metrics.index):
                fig.add_trace(
                    go.Scatter(
                        x=dates,
                        y=metrics.loc[metric].values / 1e6,  # Convert to millions
                        name=metric,
                        mode='lines+markers'
                    )
                )
            
            # Set layout
            fig.update_layout(
                title='Quarterly Financial Metrics',
                xaxis_title='Quarter',
                yaxis_title='USD (Millions)',
                template='plotly_dark',
                legend=dict(
                    orientation="h",
                    yanchor="bottom",
                    y=1.02,
                    xanchor="right",
                    x=1
                ),
                height=350,
                margin=dict(l=20, r=20, t=50, b=20)
            )
            
            return fig
    
    except Exception as e:
        # Create empty chart with error message
        fig = go.Figure()
        fig.add_annotation(
            text=f"Could not load financial metrics: {str(e)}",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=16)
        )
        return fig


def create_crypto_price_chart(data, symbol):
    """
    Create an interactive price chart for cryptocurrency
    
    Parameters:
    data (DataFrame): Historical cryptocurrency data
    symbol (str): Cryptocurrency symbol
    
    Returns:
    Figure: Plotly figure object
    """
    if data is None or data.empty:
        return go.Figure()
    
    # Create figure
    fig = go.Figure()
    
    # Add candlestick chart
    fig.add_trace(
        go.Candlestick(
            x=data['Date'],
            open=data['Open'],
            high=data['High'],
            low=data['Low'],
            close=data['Close'],
            name=symbol,
            increasing_line_color='#26a69a',
            decreasing_line_color='#ef5350'
        )
    )
    
    # Calculate moving averages
    data['MA7'] = data['Close'].rolling(window=7).mean()
    data['MA30'] = data['Close'].rolling(window=30).mean()
    
    # Add moving averages
    fig.add_trace(
        go.Scatter(
            x=data['Date'],
            y=data['MA7'],
            name='7-Day MA',
            line=dict(color='#2196f3', width=1.5)
        )
    )
    
    fig.add_trace(
        go.Scatter(
            x=data['Date'],
            y=data['MA30'],
            name='30-Day MA',
            line=dict(color='#ff9800', width=1.5)
        )
    )
    
    # Set layout
    fig.update_layout(
        title=f'{symbol} Price History',
        xaxis_title='Date',
        yaxis_title='Price (USD)',
        template='plotly_dark',
        xaxis_rangeslider_visible=False,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        ),
        height=500,
        margin=dict(l=20, r=20, t=50, b=20)
    )
    
    return fig


def create_crypto_volume_chart(data, symbol):
    """
    Create a volume chart for the cryptocurrency
    
    Parameters:
    data (DataFrame): Historical cryptocurrency data
    symbol (str): Cryptocurrency symbol
    
    Returns:
    Figure: Plotly figure object
    """
    if data is None or data.empty:
        return go.Figure()
    
    # Create color array for volume bars (green for up days, red for down days)
    colors = ['#26a69a' if data['Close'].iloc[i] >= data['Open'].iloc[i] else '#ef5350' 
              for i in range(len(data))]
    
    # Create figure
    fig = go.Figure()
    
    # Add volume bars
    fig.add_trace(
        go.Bar(
            x=data['Date'],
            y=data['Volume'],
            marker_color=colors,
            name='Volume'
        )
    )
    
    # Set layout
    fig.update_layout(
        title=f'{symbol} Trading Volume',
        xaxis_title='Date',
        yaxis_title='Volume',
        template='plotly_dark',
        height=300,
        margin=dict(l=20, r=20, t=50, b=20)
    )
    
    return fig


def create_crypto_metrics_chart(crypto_info):
    """
    Create a chart for cryptocurrency metrics
    
    Parameters:
    crypto_info (dict): Cryptocurrency information
    
    Returns:
    Figure: Plotly figure object
    """
    if not crypto_info:
        # Create empty chart with message
        fig = go.Figure()
        fig.add_annotation(
            text="Cryptocurrency data not available",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=16)
        )
        return fig
    
    # Extract price changes
    time_periods = ['1h', '24h', '7d']
    changes = [
        crypto_info.get('percent_change_1h', 0),
        crypto_info.get('percent_change_24h', 0),
        crypto_info.get('percent_change_7d', 0)
    ]
    
    # Create colors for bars (green for positive, red for negative)
    colors = ['#26a69a' if change >= 0 else '#ef5350' for change in changes]
    
    # Create figure
    fig = go.Figure()
    
    # Add bars for price changes
    fig.add_trace(
        go.Bar(
            x=time_periods,
            y=changes,
            marker_color=colors,
            name='Price Change'
        )
    )
    
    # Set layout
    fig.update_layout(
        title='Price Changes',
        xaxis_title='Time Period',
        yaxis_title='Change (%)',
        template='plotly_dark',
        height=300,
        margin=dict(l=20, r=20, t=50, b=20)
    )
    
    return fig
